<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package BuddyBoss_Theme
 */

get_header();
?>
	<?php 
	$share_box = buddyboss_theme_get_option( 'blog_share_box' );
	if ( !empty( $share_box ) && is_singular('post') ) :
		get_template_part( 'template-parts/share' ); 
	endif;
	?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<?php
            if ( wp_job_manager_is_post_type() ) :
            
                while ( have_posts() ) :
    				the_post();
    
    				get_template_part( 'template-parts/content', 'resume' );
    
    			endwhile; // End of the loop.

            elseif ( gamipress_is_post_type() ) :
                
                while ( have_posts() ) :
    				the_post();
    
    				get_template_part( 'template-parts/content', 'gamipress' );
    
    			endwhile; // End of the loop.
                
            else :
            
                while ( have_posts() ) :
    				the_post();
    
    				get_template_part( 'template-parts/content', get_post_type() );
    
    				/**
    				 * If comments are open or we have at least one comment, load up the comment template.
    				 */
    				if ( comments_open() || get_comments_number() ) :
    					comments_template();
    				endif;
    
    			endwhile; // End of the loop.
                
            endif;
			?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>

<?php
get_footer();
