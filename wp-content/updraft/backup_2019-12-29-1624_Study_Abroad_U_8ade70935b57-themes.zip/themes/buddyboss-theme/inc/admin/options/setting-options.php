<?php

require_once( dirname( __FILE__ ) . '/get-option.php' );
require_once( dirname( __FILE__ ) . '/custom-codes.php' );
require_once( dirname( __FILE__ ) . '/custom-css.php' );