=== BuddyBoss Updater ===
Contributors: buddyboss
Requires at least: 4.7
Tested up to: 5.0.3
Stable tag: 1.2.1

Manages license and update process for BuddyBoss products.

== Description ==

Manages license and update process for BuddyBoss products.

== Installation ==

1. Visit 'Plugins > Add New'
2. Click 'Upload Plugin'
3. Upload the file 'buddyboss-updater.zip'
4. Activate BuddyBoss Updater from your Plugins page.

== Changelog ==


= 1.2.1 =
* Fix - Update from same version to same version

= 1.2.0 =
* Moved license api to amazon s3 to prevent issues with firewall on buddyboss.com
* Removed some legacy code

= 1.0.2 =
* Added license codes for missing plugins and themes
* Update connector url

= 1.0.1 =
* Integration with One Click Installer

= 1.0.0 =
* Initial Release
