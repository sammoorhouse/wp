=== GT3 Unlimited Charts for Elementor Page Builder ===
Contributors: gt3themes
Tags: elementor
Requires at least: 4.6
Tested up to: 5.0.2
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


== Description ==



== Installation ==

After downloading the ZIP file,

1. Log in to WordPress dashboard panel.
2. Go to Plugins Add > New > Upload.
3. Click Choose file (Browse) and select the downloaded zip file of the plugin.
4. Click Install Now button.
5. Click Activate Plugin button for activating the plugin.
If the installation does not succeed, please contact us.

== Screenshots ==


== Frequently Asked Questions ==

== Upgrade Notice ==

== Changelog ==


Initial commit